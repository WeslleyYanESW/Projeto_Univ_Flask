from flask import Flask, request, render_template

from flask_wtf import FlaskForm
from wtforms import StringField
from wtforms.validators import DataRequired

@app.route('/home')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contato')
def about():
    return render_template('contact.html')

@app.route('/diferencial')
def about():
    return render_template('diferencial.html')

@app.route('/mercado')
def about():
    return render_template('Mercado.html')

@app.route('/porque-universidade')
def about():
    return render_template('porqueuni.html')

@app.route('/calendario')
def about():
    return render_template('calendario.html')

@app.route('/grade')
def about():
    return render_template('grade.html')


@app.route('/tipo', methods=['POST', 'GET'])
def tipo():
    if request.method == 'POST':
        return 'Solicitação via método POST'
    else:
        return 'Solicitação via método GET'

@app.route('/', methods=['POST', 'GET'])
def formulario():
    meuformulario = Form()
    if request.method == 'POST':
        if meuformulario.validate_on_submit():
            print(meuformulario.nome)
            return 'Solicitação via método POST do formulario'
        else:
            print(meuformulario.errors)
            return 'Erros ocorreram...'
    else:
        return render_template('agradecimento.html', meuform=meuformulario)


class Form(FlaskForm):
    nome = StringField('nome', validators=[DataRequired()])